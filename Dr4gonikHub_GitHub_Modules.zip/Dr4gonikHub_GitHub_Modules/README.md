# Dr4gonik Hub — GitHub module split

This package splits the supplied `Dr4gonik Hub — Premium Desktop UI v3` source into the eight requested files while preserving the original source order and function bodies.

## Files

- `loader.lua` — fetches the source fragments from GitHub, places them at their original markers, compiles the combined script, and runs it.
- `src/Core.lua` — the original code left in place with eight module markers.
- `src/modules/Themes.lua`
- `src/modules/SystemPrompt.lua`
- `src/modules/ThemeEngine.lua`
- `src/modules/Sandbox.lua`
- `src/modules/AIRequest.lua`
- `src/modules/SettingsView.lua`
- `src/modules/Markdown.lua`
- `src/modules/Messages.lua`

## Setup

1. Create a GitHub repository.
2. Upload `loader.lua` and the entire `src/` folder, retaining the folder structure shown above.
3. Open `loader.lua` and replace `YOUR_GITHUB_USERNAME/YOUR_REPOSITORY` in `RAW_BASE` with your GitHub username and repository name. Keep the branch name (`main`) consistent with your repo.
4. Run the edited loader in the same executor/runtime the original script uses.

The loader downloads `src/Core.lua` and all eight module fragments from `raw.githubusercontent.com` on each launch. To update the UI, edit and push the relevant source file to GitHub; the next launch fetches the updated version.

## Important design note

These files are **ordered source fragments**, not independent Roblox `ModuleScript`s. The original app relies on many shared Lua `local` variables and functions. The loader injects every fragment back into the exact location it occupied in the original script, then compiles the complete script as one chunk. That keeps the original lexical scope and avoids risky global-variable conversions or a large rewrite of function dependencies.

For that reason, do not call these files with `require()` individually. Always start with `loader.lua`.

## Runtime requirements

The original script uses the same executor capabilities it used before, including `game:HttpGet`, `loadstring`, and (where supported) executor HTTP/file APIs. This split does not add compatibility for runtimes that don't provide those capabilities.

## Validation

The original code was partitioned at existing section boundaries. The package's fragments can be reassembled to reproduce the original source byte-for-byte before any later edits.
