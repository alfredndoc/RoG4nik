--============================================================
--// BASE HELPERS
--============================================================
local themeKeyForColor
local ThemeRoleRegistry = setmetatable({}, { __mode = "k" })
local ThemeColorProperties = {
    BackgroundColor3 = true, TextColor3 = true, ImageColor3 = true, Color = true,
    PlaceholderColor3 = true, ScrollBarImageColor3 = true, BorderColor3 = true,
    TextStrokeColor3 = true,
}

local function create(className, props, parent)
    local inst = Instance.new(className)
    for k, v in pairs(props or {}) do
        local ok, err = pcall(function() inst[k] = v end)
        if not ok then
            debugTrace("WARN", ("Could not set %s.%s: %s"):format(className, tostring(k), tostring(err)))
        end
    end
    local roles = {}
    for propName in pairs(ThemeColorProperties) do
        local ok, value = pcall(function() return inst[propName] end)
        if ok and typeof(value) == "Color3" and themeKeyForColor then
            local role = themeKeyForColor(value, propName, Theme)
            if role then roles[propName] = role end
        end
    end
    if next(roles) then ThemeRoleRegistry[inst] = roles end
    if parent then inst.Parent = parent end
    return inst
end

local function tween(instance, goals, duration, style, direction)
    if not instance or not instance.Parent then return end
    local info = TweenInfo.new(duration or 0.18, style or Enum.EasingStyle.Quint, direction or Enum.EasingDirection.Out)
    local anim = TweenService:Create(instance, info, goals)
    anim:Play()
    return anim
end

local function corner(parent, radius) return create("UICorner", { CornerRadius = UDim.new(0, radius) }, parent) end
local function stroke(parent, color, thickness, transparency)
    return create("UIStroke", { Color = color or Theme.Border, Thickness = thickness or 1,
        Transparency = transparency or 0, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, parent)
end
local function padding(parent, l, r, t, b)
    return create("UIPadding", { PaddingLeft = UDim.new(0, l or 0), PaddingRight = UDim.new(0, r or 0),
        PaddingTop = UDim.new(0, t or 0), PaddingBottom = UDim.new(0, b or 0) }, parent)
end
local function viewportSize()
    local cam = workspace.CurrentCamera
    return cam and cam.ViewportSize or Vector2.new(1280, 720)
end

--============================================================
--// THEME RESOLUTION
--============================================================
local THEME_KEY_PRIORITY = {
    BackgroundColor3 = { "Background", "Sidebar", "Panel", "PanelRaised", "Hover", "Selected", "Accent", "AccentHover", "AccentSoft", "RightBg", "SegmentedBg", "Danger", "White" },
    TextColor3 = { "PrimaryText", "MutedText", "QuietText", "Accent", "AccentHover", "Danger", "White" },
    ImageColor3 = { "MutedText", "PrimaryText", "QuietText", "Accent", "AccentHover", "White", "Danger" },
    PlaceholderColor3 = { "QuietText", "MutedText", "PrimaryText" },
    ScrollBarImageColor3 = { "Border", "MutedText", "QuietText" },
    BorderColor3 = { "Border", "Accent", "Danger" },
    TextStrokeColor3 = { "Border", "Accent", "Danger", "PrimaryText", "White" },
    Color = { "Accent", "AccentHover", "Border", "Danger", "MutedText", "QuietText", "PrimaryText", "White" },
}

themeKeyForColor = function(c, propName, sourceTheme)
    if typeof(c) ~= "Color3" then return nil end
    sourceTheme = sourceTheme or Theme
    local priority = THEME_KEY_PRIORITY[propName]
    if priority then
        for _, key in ipairs(priority) do
            if sourceTheme[key] == c then return key end
        end
    end
    local keys = {}
    for key in pairs(sourceTheme) do keys[#keys + 1] = key end
    table.sort(keys)
    for _, key in ipairs(keys) do
        if typeof(sourceTheme[key]) == "Color3" and sourceTheme[key] == c then return key end
    end
    return nil
end

local function collectThemeChanges(root, oldTheme, newTheme)
    local changes, misses = {}, {}
    if not root then return changes, misses end

    local objects = { root }
    for _, obj in ipairs(root:GetDescendants()) do
        objects[#objects + 1] = obj
    end

    for _, obj in ipairs(objects) do
        local roles = ThemeRoleRegistry[obj]
        for propName in pairs(ThemeColorProperties) do
            local readOk, current = pcall(function()
                return obj[propName]
            end)
            if readOk and typeof(current) == "Color3" then
                local role = roles and roles[propName]
                -- If this control is currently hovered/pressed, its color may exactly
                -- match a different role than its resting color. Detect that exact role;
                -- if it is halfway through an interrupted transition, keep the registry.
                if role and oldTheme[role] ~= current then
                    local redetected = themeKeyForColor(current, propName, oldTheme)
                    if redetected then role = redetected end
                end
                if role and not newTheme[role] then role = nil end
                if not role then role = themeKeyForColor(current, propName, oldTheme) end

                if role and newTheme[role] then
                    if not roles then
                        roles = {}
                        ThemeRoleRegistry[obj] = roles
                    end
                    roles[propName] = role
                    local target = newTheme[role]
                    if target ~= current then
                        changes[#changes + 1] = {
                            object = obj,
                            property = propName,
                            from = current,
                            to = target,
                            role = role,
                        }
                    end
                elseif #misses < 60 then
                    misses[#misses + 1] = {
                        path = pathOf(obj), prop = propName, color = current,
                        reason = "no theme role match",
                    }
                end
            end
        end
    end
    return changes, misses
end


local function setTheme(name)
    if not Themes[name] then
        debugTrace("WARN", "Unknown theme: " .. tostring(name))
        return false
    end
    if name == CurrentThemeName then
        debugTrace("INFO", "Theme already active: " .. name)
        return true
    end

    local oldName = CurrentThemeName
    local oldTheme = {}
    for k, v in pairs(Theme) do oldTheme[k] = v end

    local newThemeSnapshot = {}
    for k, v in pairs(Theme) do newThemeSnapshot[k] = v end
    for k, v in pairs(Themes[name]) do newThemeSnapshot[k] = v end
    -- Theme includes font entries as well as colors. Keep the active theme table's
    -- extra fields (fonts) and only replace the theme values from the selected preset.
    for k, v in pairs(Themes[name]) do Theme[k] = v end
    CurrentThemeName = name
    saveSettings()

    local root = playerGui:FindFirstChild("DeepSeekUI")
    if not root then
        debugTrace("ERROR", "Theme root DeepSeekUI not found")
        return false
    end

    RuntimeDiagnostics.ThemeTransitionToken += 1
    local generation = RuntimeDiagnostics.ThemeTransitionToken

    -- Cancel the previous animation cleanly. An interrupted transition starts from
    -- the actual on-screen colors, not from a stale theme snapshot.
    if RuntimeDiagnostics.ActiveThemeTween then
        pcall(function() RuntimeDiagnostics.ActiveThemeTween:Cancel() end)
        RuntimeDiagnostics.ActiveThemeTween = nil
    end
    if RuntimeDiagnostics.ActiveThemeConnection then
        pcall(function() RuntimeDiagnostics.ActiveThemeConnection:Disconnect() end)
        RuntimeDiagnostics.ActiveThemeConnection = nil
    end
    if RuntimeDiagnostics.ActiveThemeProgress then
        pcall(function() RuntimeDiagnostics.ActiveThemeProgress:Destroy() end)
        RuntimeDiagnostics.ActiveThemeProgress = nil
    end

    local changes, misses = collectThemeChanges(root, oldTheme, newThemeSnapshot)
    local overlay = RuntimeDiagnostics.ThemeTransitionOverlay
    local overlayStartBg = overlay and overlay.BackgroundColor3 or oldTheme.Background
    local overlayGoalBg = newThemeSnapshot.Background or Theme.Background
    local overlayGradient = overlay and overlay:FindFirstChildOfClass("UIGradient")
    local oldAccent = oldTheme.Accent or Theme.Accent
    local oldAccentHover = oldTheme.AccentHover or oldAccent
    local newAccent = newThemeSnapshot.Accent or Theme.Accent
    local newAccentHover = newThemeSnapshot.AccentHover or newAccent

    local function finishThemeTransition()
        if generation ~= RuntimeDiagnostics.ThemeTransitionToken then return end
        for _, change in ipairs(changes) do
            if change.object and change.object.Parent then
                pcall(function() change.object[change.property] = change.to end)
            end
        end
        if overlay and overlay.Parent then
            overlay.BackgroundTransparency = 1
            overlay.BackgroundColor3 = overlayGoalBg
        end
        if overlayGradient then
            overlayGradient.Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, newAccent),
                ColorSequenceKeypoint.new(0.5, newAccentHover),
                ColorSequenceKeypoint.new(1, newAccent),
            })
        end

        ThemeDebug.TotalUpdates += #changes
        ThemeDebug.TotalMisses += #misses
        ThemeDebug.LastMisses = misses
        ThemeDebug.History[#ThemeDebug.History + 1] = {
            from = oldName, to = name, updates = #changes, misses = #misses,
            timestamp = os.clock(), detail = misses,
        }
        if #ThemeDebug.History > 30 then table.remove(ThemeDebug.History, 1) end

        RuntimeDiagnostics.ThemeSwitchCount += 1
        RuntimeDiagnostics.LastThemeColorUpdates = #changes
        RuntimeDiagnostics.LastThemeSwitch = ("%s → %s · %d animated · %d missed"):format(oldName, name, #changes, #misses)
        debugTrace(#misses > 0 and "WARN" or "INFO", "Theme switch: " .. RuntimeDiagnostics.LastThemeSwitch)
        if RuntimeDiagnostics.ThemeDebugLabel and RuntimeDiagnostics.ThemeDebugLabel.Parent then
            RuntimeDiagnostics.ThemeDebugLabel.Text = "Theme engine: " .. RuntimeDiagnostics.LastThemeSwitch
            RuntimeDiagnostics.ThemeDebugLabel.TextColor3 = #misses > 0 and Theme.Danger or Theme.MutedText
        end
        if RuntimeDiagnostics.ActiveThemeConnection then
            RuntimeDiagnostics.ActiveThemeConnection:Disconnect()
            RuntimeDiagnostics.ActiveThemeConnection = nil
        end
        if RuntimeDiagnostics.ActiveThemeProgress then
            RuntimeDiagnostics.ActiveThemeProgress:Destroy()
            RuntimeDiagnostics.ActiveThemeProgress = nil
        end
        RuntimeDiagnostics.ActiveThemeTween = nil
    end

    if #changes == 0 then
        finishThemeTransition()
        return #misses == 0
    end

    -- One shared progress tween drives every affected color. This avoids creating
    -- hundreds of individual property tweens and ensures the entire UI transitions
    -- together instead of changing control-by-control.
    local progress = Instance.new("NumberValue")
    progress.Name = "ThemeTransitionProgress"
    progress.Value = 0
    RuntimeDiagnostics.ActiveThemeProgress = progress

    local function applyProgress(alpha)
        if generation ~= RuntimeDiagnostics.ThemeTransitionToken then return end
        for _, change in ipairs(changes) do
            local obj = change.object
            if obj and obj.Parent then
                pcall(function()
                    obj[change.property] = change.from:Lerp(change.to, alpha)
                end)
            end
        end
        if overlay and overlay.Parent then
            overlay.BackgroundColor3 = overlayStartBg:Lerp(overlayGoalBg, alpha)
            -- A subtle wash gives the transition a cohesive gradient feel without
            -- hiding the UI or blocking input.
            overlay.BackgroundTransparency = 0.965 + (0.035 * alpha)
        end
        if overlayGradient then
            overlayGradient.Color = ColorSequence.new({
                ColorSequenceKeypoint.new(0, oldAccent:Lerp(newAccent, alpha)),
                ColorSequenceKeypoint.new(0.5, oldAccentHover:Lerp(newAccentHover, alpha)),
                ColorSequenceKeypoint.new(1, oldAccent:Lerp(newAccent, alpha)),
            })
        end
    end

    RuntimeDiagnostics.ActiveThemeConnection = progress:GetPropertyChangedSignal("Value"):Connect(function()
        applyProgress(progress.Value)
    end)
    RuntimeDiagnostics.ActiveThemeTween = TweenService:Create(
        progress,
        TweenInfo.new(0.34, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut),
        { Value = 1 }
    )
    RuntimeDiagnostics.ActiveThemeTween.Completed:Connect(function(playbackState)
        if playbackState == Enum.PlaybackState.Completed then
            finishThemeTransition()
        end
    end)
    RuntimeDiagnostics.ActiveThemeTween:Play()
    return true
end
